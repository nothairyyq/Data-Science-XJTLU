function f=cal(x)
f=(-3)*x^5+2*x^4-x^3+4;
end
